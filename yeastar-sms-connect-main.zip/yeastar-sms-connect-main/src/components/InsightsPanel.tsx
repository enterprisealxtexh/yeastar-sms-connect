import { useState } from "react";
import { Button } from "@/components/ui/button";
import { AnalyticsDashboard } from "@/components/AnalyticsDashboard";
import { ActivityLog } from "@/components/ActivityLog";
import { AiAutomationPanel } from "@/components/AiAutomationPanel";
import { PredictiveMaintenancePanel } from "@/components/PredictiveMaintenancePanel";
import { ErrorLogsPanel } from "@/components/ErrorLogsPanel";
import { AiConfigPanel } from "@/components/AiConfigPanel";
import { TelegramPanel } from "@/components/TelegramPanel";
import { MissedCallsReportPanel } from "@/components/MissedCallsReportPanel";
import { useActivityLogs } from "@/hooks/useActivityLogs";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { BarChart3, FileText, ScrollText, BrainCircuit, Send } from "lucide-react";

type Section = "analytics" | "reports" | "logs" | "ai" | "telegram";

interface SectionItem {
  id: Section;
  label: string;
  icon: React.ElementType;
}

const sections: SectionItem[] = [
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "reports", label: "Reports", icon: FileText },
  { id: "logs", label: "Logs", icon: ScrollText },
  { id: "ai", label: "AI & Diagnostics", icon: BrainCircuit },
  { id: "telegram", label: "Telegram", icon: Send },
];

export const InsightsPanel = () => {
  const [active, setActive] = useState<Section>("analytics");
  const { data: logs = [], isLoading: logsLoading, isStreaming } = useActivityLogs();

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {sections.map(s => (
          <Button
            key={s.id}
            variant={active === s.id ? "default" : "outline"}
            size="sm"
            className={cn("gap-2", active === s.id && "shadow-md")}
            onClick={() => setActive(s.id)}
          >
            <s.icon className="w-4 h-4" />
            {s.label}
          </Button>
        ))}
      </div>

      <div className="min-h-[400px]">
        {active === "analytics" && <AnalyticsDashboard />}
        {active === "reports" && <MissedCallsReportPanel />}
        {active === "logs" && (
          logsLoading ? <Skeleton className="h-[400px] rounded-lg" /> : <ActivityLog logs={logs} isStreaming={isStreaming} />
        )}
        {active === "ai" && (
          <div className="space-y-4">
            <AiAutomationPanel />
            <PredictiveMaintenancePanel />
            <div className="grid gap-4 lg:grid-cols-2">
              <ErrorLogsPanel />
              <AiConfigPanel />
            </div>
          </div>
        )}
        {active === "telegram" && <TelegramPanel />}
      </div>
    </div>
  );
};
