import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { Header } from "@/components/Header";
import { SimPortCard } from "@/components/SimPortCard";
import { SystemStatusCard } from "@/components/SystemStatusCard";
import { SmsInbox } from "@/components/SmsInbox";

import { ConfigurationPanel } from "@/components/ConfigurationPanel";
import { CommunicationsPanel } from "@/components/CommunicationsPanel";
import { InsightsPanel } from "@/components/InsightsPanel";
import { StaffPanel } from "@/components/StaffPanel";
import { RoleManagementPanel } from "@/components/RoleManagementPanel";
import { DashboardSidebar, DashboardTab } from "@/components/DashboardSidebar";
import { Skeleton } from "@/components/ui/skeleton";
import { Server, Phone, Database } from "lucide-react";
import { toast } from "sonner";
import { useSimPorts } from "@/hooks/useSimPorts";
import { useSmsMessages } from "@/hooks/useSmsMessages";

import { useDashboardStats } from "@/hooks/useDashboardStats";

const Index = () => {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<DashboardTab>("dashboard");
  const [lastSync, setLastSync] = useState(() => new Date().toLocaleString("sv-SE").replace(",", ""));

  const { data: simData, isLoading: simLoading } = useSimPorts();
  const simPorts = simData?.ports || [];
  const simConfigs = simData?.configs || [];
  const { data: messages = [], isLoading: messagesLoading } = useSmsMessages();
  
  const { data: stats, isLoading: statsLoading } = useDashboardStats();

  const handleRefresh = async () => {
    await queryClient.invalidateQueries();
    const now = new Date().toLocaleString("sv-SE").replace(",", "");
    setLastSync(now);
    toast.success("System data refreshed");
  };

  const systemStatus = simPorts.some((p) => p.status === "online")
    ? "online"
    : simPorts.some((p) => p.status === "warning")
    ? "warning"
    : "offline";

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header systemStatus={systemStatus} lastSync={lastSync} onRefresh={handleRefresh} />

      <div className="flex flex-1 overflow-hidden">
        <DashboardSidebar activeTab={activeTab} onTabChange={setActiveTab} />

        <main className="flex-1 overflow-y-auto p-3 md:p-6 pb-20 md:pb-6 space-y-4 md:space-y-6">
          {activeTab === "dashboard" && (
            <>
              {/* System Status Row */}
              <ErrorBoundary fallbackTitle="System Status">
                <div className="grid gap-4 md:grid-cols-3">
                  <SystemStatusCard
                    title="TG400 Gateway"
                    status={systemStatus}
                    statusLabel={systemStatus === "online" ? "Connected" : systemStatus === "warning" ? "Degraded" : "Disconnected"}
                    icon={Server}
                    details={[
                      { label: "Active SIMs", value: statsLoading ? "..." : `${stats?.activeSims || 0}/${stats?.totalSims || 0}` },
                      { label: "Last Poll", value: lastSync.split(" ")[1] || lastSync },
                    ]}
                  />
                  <SystemStatusCard
                    title="S100 PBX"
                    status="online"
                    statusLabel="Connected"
                    icon={Phone}
                    details={[
                      { label: "Extensions", value: "Configured" },
                      { label: "SMS Queue", value: statsLoading ? "..." : `${stats?.unreadMessages || 0} pending` },
                    ]}
                  />
                  <SystemStatusCard
                    title="Message Store"
                    status="online"
                    statusLabel="Healthy"
                    icon={Database}
                    details={[
                      { label: "Total Messages", value: statsLoading ? "..." : stats?.totalMessages.toLocaleString() || "0" },
                      { label: "Unread", value: statsLoading ? "..." : stats?.unreadMessages.toLocaleString() || "0" },
                    ]}
                  />
                </div>
              </ErrorBoundary>

              {/* SIM Ports Row */}
              <ErrorBoundary fallbackTitle="SIM Ports">
                <div>
                  <h2 className="text-sm font-medium text-muted-foreground mb-4">SIM Port Status</h2>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    {simLoading ? (
                      Array.from({ length: 4 }).map((_, i) => (
                        <Skeleton key={i} className="h-[180px] rounded-lg" />
                      ))
                    ) : (
                      simPorts.map((sim) => <SimPortCard key={sim.port} {...sim} />)
                    )}
                  </div>
                </div>
              </ErrorBoundary>

              {/* Messages Row */}
              <ErrorBoundary fallbackTitle="SMS Inbox">
                <div>
                  {messagesLoading ? (
                    <Skeleton className="h-[400px] rounded-lg" />
                  ) : (
                    <SmsInbox messages={messages} />
                  )}
                </div>
              </ErrorBoundary>
            </>
          )}

          {activeTab === "comms" && (
            <ErrorBoundary fallbackTitle="Calls & Contacts">
              <CommunicationsPanel />
            </ErrorBoundary>
          )}

          {activeTab === "insights" && (
            <ErrorBoundary fallbackTitle="Insights">
              <InsightsPanel />
            </ErrorBoundary>
          )}

          {activeTab === "config" && (
            <ErrorBoundary fallbackTitle="Configuration">
              <ConfigurationPanel
                simPorts={simConfigs}
                isLoading={simLoading}
                onConfigSaved={() => queryClient.invalidateQueries({ queryKey: ["sim-ports"] })}
              />
            </ErrorBoundary>
          )}

          {activeTab === "staff" && (
            <ErrorBoundary fallbackTitle="Staff">
              <StaffPanel />
            </ErrorBoundary>
          )}

          {activeTab === "roles" && (
            <ErrorBoundary fallbackTitle="Roles">
              <RoleManagementPanel />
            </ErrorBoundary>
          )}
        </main>
      </div>
    </div>
  );
};

export default Index;
